class PlanetPort {
  async createPlanet(planetData) {
    throw new Error("Method not implemented");
  }

  async getAllPlanets() {
    throw new Error("Method not implemented");
  }
}

export default PlanetPort;
